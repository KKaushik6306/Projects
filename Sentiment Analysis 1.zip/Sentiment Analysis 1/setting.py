import nltk

nltk.download()
